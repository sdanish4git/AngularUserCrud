export class Teacher{
    
    
    constructor(private name:string,private email:string,private school:string){
        
    }
}