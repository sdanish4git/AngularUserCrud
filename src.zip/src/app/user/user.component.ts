import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, observable, Observable, range, Subscription } from 'rxjs';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  constructor(private userService:UserService){

  }
  users:User[]=[];
  newUser:User=new User(0,'','');
  msg:string='';
  ngOnInit(){
    this.getAllUsers();
  }
  insertUser(){
    this.userService.saveUserData(this.newUser).subscribe(
      data => {
        this.msg=data.message;
        this.newUser.email='';
        this.newUser.name='';
        this.getAllUsers();
      },
      error => console.log(error)
    );
  }

  getAllUsers(){
    this.userService.getAllUsers().subscribe(
      data => this.users=data,
      error => console.log(error)
    );
  }


  // subscription?:Subscription;
  // ngOnInit(){
  //   var mynumbers=range(2,10);
  //   this.subscription=mynumbers.subscribe(
  //     (n) => {
  //       console.log(n);
  //     },
  //     (error)=>{
  //       console.log(error);
  //     },
  //     ()=>{
  //       console.log("completed");
  //     }
  //   );
    
  // }
  // ngOnDestroy(){
  //   this.subscription?.unsubscribe();
  // }

//   insertUser(){
//      //let user=new User(0,this.userName,this.email);
    
//     this.userService.saveUserData(user).subscribe(
//        data => {
//          console.log(data.message)
//          //this.msg=data.message;
//        },
//        error => {
//          console.log("errorrrrrr ");
//        }
//      );
  
// }
  
}
