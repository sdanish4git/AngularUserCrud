export class User{
    id:number=0;
    name:string='';
    email:string='';
    
    constructor(userId:number,uname:string,email:string){
        this.name=uname;
        this.email=email;
        this.id=userId;
    }
}