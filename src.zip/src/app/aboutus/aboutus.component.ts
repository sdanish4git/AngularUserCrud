import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit,OnDestroy {

  constructor() { }

  ngOnInit(){
    console.log("intit  called");
  }
  ngOnDestroy(){
    console.log("destryed called");
  }

}
